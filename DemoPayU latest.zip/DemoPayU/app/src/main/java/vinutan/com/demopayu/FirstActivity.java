package vinutan.com.demopayu;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

public class FirstActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent intent = new Intent(FirstActivity.this,MainActivity.class);
        intent.putExtra("name", "Ravindra");
        intent.putExtra("email", "benaleravi@gmail.com");
        intent.putExtra("amount",1);
        intent.putExtra("phone","9730332842");
        intent.putExtra("id",5622616);
        intent.putExtra("isFromOrder",false);

        finish();


    }

}
